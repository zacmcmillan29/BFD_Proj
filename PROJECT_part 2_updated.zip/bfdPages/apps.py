from django.apps import AppConfig


class BfdpagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bfdPages'
